# Juryen — Personal AI Assistant

Juryen is an Android voice assistant with an optional natural-language AI command planner and an Accessibility-based action executor.

## AI command engine
Set an Anthropic API key in the app's setup screen. Commands that are not handled locally are sent to Claude, which returns a strict JSON action plan. Juryen executes only the allow-listed action types:

- `open_app`
- `tap_text`
- `tap_description`
- `type_text`
- `back`
- `home`
- `wait`
- `swipe_up` / `swipe_down`
- `select_first_image`
- `open_url`

The API key is stored in the app's private SharedPreferences and is never included in source control.

## Creator identity
Questions about the creator are handled locally and always return **Sajim Ahmed**.

## Required Android permissions
The owner must manually grant microphone permission and enable Juryen under Android Accessibility settings. Android does not allow an ordinary app to silently grant itself Accessibility access.

## Build
Open the `Juryen` folder in Android Studio and allow Gradle to sync. Then build `app` → `assembleDebug` or press Run.

## Validation note
This environment did not contain a Gradle installation or Android SDK, so a real APK compilation could not be performed here. The Kotlin/manifest/resources were inspected and corrected for the supplied project; Android Studio should perform the authoritative Gradle/SDK build.


## Juryen Voice
Juryen now prefers an available English female/high-quality TTS voice and applies a soft, slightly slower speaking profile. Voice availability and naturalness depend on the Android TTS engine and voice packs installed on the device. For the most human-like result, install/update a high-quality English female voice in the phone's Text-to-Speech settings.
