package com.sajimahmed.juryen.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.sajimahmed.juryen.R
import com.sajimahmed.juryen.util.CommandProcessor
import com.sajimahmed.juryen.util.JuryenVoice
import java.util.Locale

/**
 * Runs as a foreground service so Android does not kill it, and keeps
 * restarting speech recognition in a loop so the phone is always "listening"
 * for the wake word, including on the lock screen.
 *
 * IMPORTANT REAL-WORLD LIMITATION:
 * Android's SpeechRecognizer needs an active recognition session to hear
 * anything - there is no free always-on microphone tap for third-party apps.
 * This service restarts recognition immediately every time it ends, which
 * gets close to "always listening" but will have brief gaps and will use
 * noticeable battery. For production-grade always-on wake word with low
 * battery use, integrate an offline wake-word engine (e.g. Porcupine) later.
 */
class JuryenListenerService : Service(), RecognitionListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var juryenVoice: JuryenVoice
    private lateinit var commandProcessor: CommandProcessor
    private var listening = false

    companion object {
        const val CHANNEL_ID = "juryen_listener_channel"
        const val NOTIFICATION_ID = 101
        const val WAKE_WORD = "juryen"
    }

    override fun onCreate() {
        super.onCreate()
        // Configure Juryen to prefer a soft, natural female TTS voice exposed by the device.
        juryenVoice = JuryenVoice(this)
        juryenVoice.initialize()
        tts = juryenVoice.rawTts()
        commandProcessor = CommandProcessor(this, tts)
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification(), foregroundType())
        startListening()
        return START_STICKY
    }

    private fun foregroundType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else 0

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Juryen Assistant", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Juryen is listening")
            .setContentText("Say \"Juryen\" to give a command")
            .setSmallIcon(R.drawable.ic_juryen_logo)
            .setOngoing(true)
            .build()
    }

    private fun startListening() {
        if (listening) return
        listening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer.startListening(intent)
    }

    // ----- RecognitionListener callbacks -----

    override fun onResults(results: Bundle?) {
        listening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val heard = matches?.firstOrNull()?.lowercase(Locale.getDefault()) ?: ""
        handleHeardText(heard)
        // restart the loop so it keeps "always listening"
        startListening()
    }

    override fun onError(error: Int) {
        listening = false
        // Restart on any error (timeout, no match, etc.) to keep the loop alive.
        startListening()
    }

    private fun handleHeardText(heard: String) {
        if (heard.contains(WAKE_WORD)) {
            val afterWakeWord = heard.substringAfter(WAKE_WORD).trim()
            if (afterWakeWord.isNotEmpty()) {
                commandProcessor.process(afterWakeWord)
            } else {
                juryenVoice.speak("Yes?")
            }
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        speechRecognizer.destroy()
        juryenVoice.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
