package com.sajimahmed.juryen.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.sajimahmed.juryen.databinding.ActivityMainBinding
import com.sajimahmed.juryen.service.JuryenListenerService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startListenerService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val savedKey = getSharedPreferences("juryen_settings", MODE_PRIVATE).getString("anthropic_api_key", "")
        binding.etApiKey.setText(savedKey)
        binding.btnGrantPermissions.setOnClickListener { saveApiKey(); requestNeededPermissions() }
        binding.btnOpenAccessibility.setOnClickListener { openAccessibilitySettings() }
        binding.btnStart.setOnClickListener {
            saveApiKey()
            requestNeededPermissions()
        }
    }

    private fun saveApiKey() {
        getSharedPreferences("juryen_settings", MODE_PRIVATE).edit()
            .putString("anthropic_api_key", binding.etApiKey.text.toString().trim())
            .apply()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun startListenerService() {
        val intent = Intent(this, JuryenListenerService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        binding.tvStatus.text = "Juryen is active. Say \"Juryen\" followed by a command."
    }
}
